Download links of respective datasets:
1. https://cs.joensuu.fi/sipu/datasets/
2. https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/
3. https://archive.ics.uci.edu/ml/datasets/Connectionist+Bench+%28Sonar%2C+Mines+vs.+Rocks%29
4. https://archive.ics.uci.edu/ml/datasets/Ionosphere